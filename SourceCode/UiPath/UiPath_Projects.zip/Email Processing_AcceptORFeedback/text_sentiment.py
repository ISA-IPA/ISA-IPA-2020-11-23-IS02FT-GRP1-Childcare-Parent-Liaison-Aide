import nltk
nltk.download('vader_lexicon')
from nltk.sentiment.vader import SentimentIntensityAnalyzer

sid = SentimentIntensityAnalyzer()

def sentiment(text):
    sid = SentimentIntensityAnalyzer()
    senti_dict = sid.polarity_scores(text)
    result_compound = senti_dict['compound']
    return( result_compound )

